import { Injectable } from '@angular/core';
import { IEmployee } from './i-employee';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SEmployeeService {
  
  readonly filePath = "api/employees/"
  employees: IEmployee[];
  constructor(private httpService: HttpClient) { }
  addEmployee(addedEmployee: IEmployee):Observable<IEmployee> {
      return this.httpService.post<IEmployee>(this.filePath,addedEmployee)
  }

  getEmployeesInitially(): Observable<IEmployee[]> {
    //this function runs for first time
   return this.httpService.get<IEmployee[]>(this.filePath);
  }
  getEmployeeById(id:number): Observable<IEmployee> {
    //this function runs for first time
    console.log(id)
   return this.httpService.get<IEmployee>("api/employees/"+id);
  }
  setEmployeesInitially(employeesList: IEmployee[]) {
    //set the employees array for future use
    this.employees = employeesList; 
  }
  getSetEmployees() {
    // get the set employees, which runs after first time
    return this.employees; 
  }
  onDeleteEmployee(employee: IEmployee) {
    //deleting the data
    let index = this.employees.indexOf(employee);
    this.employees.splice(index, 1);
  }
  onUpdateEmployee(employee: IEmployee) {
  //updating the data
  if(employee.id===0){}
    let index = this.employees.indexOf(employee);
  this.employees.splice(index, 1);
  }
}
