import { Component } from '@angular/core';
//decorator
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
 //template: ' <h1>  {{name }} </h1>',
  styleUrls: ['./app.component.css']
})

//class in typescript 
export class AppComponent {
  title:string  = 'My firstAngular App';
  name="Angular Developer/UI Developer";
  city="Hyderabad"

  customerData: any[] = [ {
    "ID": "1",
    "name": 'John'
 },

 {
    "ID": "2",
    "name": 'Smith'
 } 

];

months=["January","Feburary","March","April","May",
"June","July","August","September",
"October","November","December"];

isvalid=true;

myClickFunction(event){
   alert("Button is clicked");
  console.log(event);
  }
  changemonths(event){
    alert("Changed month from the Dropdown");
    console.log('changed');
    }
    
  
  

}
