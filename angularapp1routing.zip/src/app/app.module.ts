import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AppRoutingModule } from './app.routing.module'; 
import { FeedbackComponent} from './feedback/feedback.component'
@NgModule({
  declarations: [
   
   
    AppComponent,
    HomeComponent,
    ContactusComponent,
    FeedbackComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
