import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularapp1';

  callme(event) {
    alert ("button is clicked");
    console.log("event binded");
  }

  todaydate=new Date();


  jsonval = {    name:'Rox', age:'25', address:{city:'Mumbai', state:'Karnataka'} ,
  
 }; 



  months = ["Jan", "Feb", "Mar", "April", "May", "Jun", "July", "Aug", 
     "Sept", "Oct", "Nov", "Dec"]; 
  
}
