import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewchildcomponentComponent } from './newchildcomponent.component';

describe('NewchildcomponentComponent', () => {
  let component: NewchildcomponentComponent;
  let fixture: ComponentFixture<NewchildcomponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewchildcomponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewchildcomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
