import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-newchildcomponent',
  templateUrl: './newchildcomponent.component.html',
  styleUrls: ['./newchildcomponent.component.css']
})
export class NewchildcomponentComponent implements OnInit {
 num;
  constructor() { }

  ngOnInit(): void {
    const sqnc = new Observable(countOnetoTen);
    sqnc.subscribe({
           next(num) { console.log(num); }
       });
    function countOnetoTen(observer) {
            
           for(var i = 1; i <= 10; i++) {
                
               observer.next(i);
           }
        
       return {unsubscribe(){}};
       }

  }

}
