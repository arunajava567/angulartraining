var i = 2;
do {
    console.log("Block statement execution no." + i);
    i++;
} while (i < 4);
