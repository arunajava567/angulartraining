console.log("welcome to typescript");
var message = "Hello World";
console.log(message);
